# The GreenLeaf Society — free website starter

## Included
- `index.html` — responsive single-page site
- `style.css` — premium black and dark-green styling, mobile layout
- `script.js` — catalogue filters, demo saved-items bag, WhatsApp link placeholder

## Important legal and technical limits
This is a catalogue/design starter, not a live THC store. The bag is only a local demo list; it does not create orders, collect customer information, take payments, or arrange cannabis delivery. It intentionally does not list cannabis flower/THC for sale. South African law distinguishes private adult use from commercial dealing; get current South African legal advice and confirm applicable authorisations before any commercial activity. A website host's terms and payment-provider rules also apply.

## Set up on iPhone 11
1. Download and unzip `greenleaf_society_site.zip` in the Files app.
2. To preview locally, tap `index.html` from Files if iOS offers a browser preview. For a reliable hosted preview, use a free static host below.
3. Edit `script.js` and set `WHATSAPP_NUMBER` to your WhatsApp number in international digits-only format, e.g. `27XXXXXXXXX`. Do not include `+`, spaces, or brackets.
4. Replace brand copy and placeholder lawful product information in `index.html` before launch. Keep the legal notice accurate.

## Free publishing option: GitHub Pages
1. Create/sign in to a GitHub account in Safari.
2. Create a **public** repository named `greenleaf-society-site`.
3. Upload `index.html`, `style.css`, and `script.js` from the unzipped folder (repository → Add file → Upload files).
4. Open repository **Settings → Pages**.
5. Under build/deployment, choose **Deploy from a branch**, select `main` and `/ (root)`, then Save.
6. Wait for GitHub Pages to publish and open the URL shown in Settings → Pages. It usually resembles `https://YOUR-USERNAME.github.io/greenleaf-society-site/`.
7. Test on your iPhone, including navigation, filters, bag and WhatsApp link.

Hosting providers can change free-tier terms. GitHub Pages is for static sites and does not provide a backend, database, secure checkout, inventory system or order management. Never collect payment card details in this static site.

## To make it production-ready
- Use only products and business activity that are lawful and appropriately authorised.
- Add real contact details, privacy notice, terms, returns policy and accurate delivery information.
- If later using a checkout/payment provider, verify its cannabis-related policies and South African availability before building around it.
