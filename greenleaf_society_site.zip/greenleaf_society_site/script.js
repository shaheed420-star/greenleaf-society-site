// Demo-only catalogue bag. It does not create orders or process payments.
const state = { saved: [] };
const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];
$("#year").textContent = new Date().getFullYear();

$("#menuToggle").addEventListener("click", () => $("#nav").classList.toggle("open"));
$$("nav a").forEach(link => link.addEventListener("click", () => $("#nav").classList.remove("open")));

function openCart() {
  document.body.classList.add("cart-open");
  $("#cartDrawer").setAttribute("aria-hidden", "false");
}
function closeCart() {
  document.body.classList.remove("cart-open");
  $("#cartDrawer").setAttribute("aria-hidden", "true");
}
$("#openCart").addEventListener("click", openCart);
$("#closeCart").addEventListener("click", closeCart);
$("#backdrop").addEventListener("click", closeCart);

function toast(message) {
  const el = $("#toast");
  el.textContent = message;
  el.classList.add("show");
  window.setTimeout(() => el.classList.remove("show"), 2300);
}
function renderCart() {
  $("#cartCount").textContent = state.saved.length;
  const holder = $("#cartItems");
  if (!state.saved.length) {
    holder.innerHTML = '<p class="empty-cart">Your bag is empty.</p>';
    return;
  }
  holder.innerHTML = state.saved.map((name, i) =>
    `<div class="cart-row"><span>${escapeHtml(name)}</span><button data-remove="${i}">Remove</button></div>`
  ).join("");
  $$("[data-remove]").forEach(button => button.addEventListener("click", () => {
    state.saved.splice(Number(button.dataset.remove), 1);
    renderCart();
  }));
}
function escapeHtml(value) {
  return value.replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
}
$$(".add-button").forEach(button => button.addEventListener("click", () => {
  toast(button.dataset.info + " — catalogue demo only.");
  state.saved.push(button.dataset.info);
  renderCart();
}));
$("#clearCart").addEventListener("click", () => {
  state.saved = [];
  renderCart();
});
$$(".filter").forEach(button => button.addEventListener("click", () => {
  $$(".filter").forEach(item => item.classList.toggle("active", item === button));
  const category = button.dataset.filter;
  $$(".product-card").forEach(card => {
    card.hidden = category !== "all" && card.dataset.category !== category;
  });
}));

// Replace with your WhatsApp number in international format, digits only.
// South Africa example format: 27XXXXXXXXX (do not include + or spaces).
const WHATSAPP_NUMBER = "";
const whatsapp = $("#whatsappLink");
if (WHATSAPP_NUMBER) {
  whatsapp.href = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent("Hi The GreenLeaf Society, I have a question about your catalogue.")}`;
} else {
  whatsapp.href = "https://wa.me/";
  whatsapp.addEventListener("click", event => {
    event.preventDefault();
    toast("Add your WhatsApp number in script.js first.");
  });
}
renderCart();
